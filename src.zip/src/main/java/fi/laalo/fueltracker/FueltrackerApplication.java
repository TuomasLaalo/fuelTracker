package fi.laalo.fueltracker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FueltrackerApplication {

	public static void main(String[] args) {
		SpringApplication.run(FueltrackerApplication.class, args);
	}

}
