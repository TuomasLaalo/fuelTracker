package fi.laalo.fueltracker.dto;

public record UserResponseDTO(
        Long id,
        String email
) {}
